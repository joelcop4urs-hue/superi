package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
)

var users = map[string]string{
	"admin": "admin",
}

type Req struct {
	Value  string `json:"value"`
	Output string `json:"output"`
}

var dataStore = make(map[string]Req)

// API to receive key and output and store in map
func getValueHandler(w http.ResponseWriter, r *http.Request) {
	// auth check
	w.Header().Set("Content-Type", "application/json")

	// get "key" query string (?key=foo)
	key := r.URL.Query().Get("key")

	if val, ok := dataStore[key]; ok {
		// key found → return stored Req
		json.NewEncoder(w).Encode(val)
	} else {
		// key not found → return fallback response
		json.NewEncoder(w).Encode(Req{
			Value:  "",
			Output: "",
		})
	}
}
func setOutputHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Output string `json:"output"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	key := r.URL.Query().Get("key")
	if key == "" {
		http.Error(w, "Missing key parameter", http.StatusBadRequest)
		return
	}

	dataStore[key] = Req{
		Value:  "",
		Output: req.Output,
	}

	w.WriteHeader(http.StatusOK)
	w.Write([]byte("stored"))
}

func renderHTML(w http.ResponseWriter, filename string) {
	w.Header().Set("Content-Type", "text/html")
	path := filepath.Join("", filename)
	data, err := os.ReadFile(path)
	if err != nil {
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		return
	}
	w.Write(data)
}

func loginPage(w http.ResponseWriter, r *http.Request) {
	renderHTML(w, "login.html")
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		fmt.Println(r.RequestURI)

		loginPage(w, r)

		return
	}
	username := r.FormValue("username")
	password := r.FormValue("password")
	if pass, ok := users[username]; ok && pass == password {
		http.SetCookie(w, &http.Cookie{Name: "auth", Value: "admin", Path: "/"})
		http.Redirect(w, r, "/app", http.StatusSeeOther)
	} else {
		w.WriteHeader(http.StatusUnauthorized)
		renderHTML(w, "login_failed.html")
	}
}

func appPage(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("auth")
	if err != nil || cookie.Value != "admin" {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}
	renderHTML(w, "app.html")
}

func submitHandler(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("auth")
	if err != nil || cookie.Value != "admin" {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}
	fmt.Println(r)
	if r.Method == "POST" {
		key := r.FormValue("key")
		value := r.FormValue("value")
		if key != "" {
			dataStore[key] = Req{Value: value, Output: ""}
		}
		http.Redirect(w, r, "/app", http.StatusSeeOther)
	} else {
		http.Redirect(w, r, "/app", http.StatusSeeOther)
	}
}

func dataHandler(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("auth")
	if err != nil || cookie.Value != "admin" {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(dataStore)
}

func main() {
	http.HandleFunc("/login", loginHandler)
	http.HandleFunc("/app", appPage)
	http.HandleFunc("/submit", submitHandler)
	http.HandleFunc("/data", dataHandler)
	http.HandleFunc("/getvalue", getValueHandler)
	http.HandleFunc("/setoutput", setOutputHandler)
	fmt.Println("Server running on :8080")
	http.ListenAndServe(":8080", nil)
}
